<?php 
// Silence is golden
