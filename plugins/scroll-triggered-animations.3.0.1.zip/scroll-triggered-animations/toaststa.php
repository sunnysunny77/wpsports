<?php
   /*
   * Plugin Name: Scroll Triggered Animations
   * Plugin URI: https://www.toastplugins.co.uk/plugins/scroll-triggered-animations/
   * Description: The ultimate platform for creating & managing CSS animations on your WordPress website.
   * Version: 3.0.1
   * Author: Toast Plugins
   * Author URI: https://www.toastplugins.co.uk/
   * Licence: GPLv2 or later
   */

	include dirname(__FILE__) . '/backend/init.php';
	include dirname(__FILE__) . '/frontend/init.php';
?>