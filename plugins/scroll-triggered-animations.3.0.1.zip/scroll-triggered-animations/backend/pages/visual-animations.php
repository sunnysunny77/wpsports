<div class="page" data-name="visual">
	<h2 class="page-title">Visual Animation Builder</h2>
	<div class="page-content">
		<div class="visual-animations-advert">
		<h2>Visual Animation Builder</h2>
		<h4>A new way to build animations is coming soon.</h4>
		The Visual Animation builder is a project that we have been working on to make custom animating an easier task for those of you who aren't advanced in webcode. Visual animation builder will be available within the Pro extension package within 2021 so keep an eye out for updates.
		</div>
	</div>
</div>