<?php
/**
 * Update version.
 */
update_option( 'wp_carousel_free_version', WPCAROUSELF_VERSION );
update_option( 'wp_carousel_free_db_version', WPCAROUSELF_VERSION );
