<?php
// locale: native portuguese (pt_PT)

return require __DIR__ . '/pt_BR.php';